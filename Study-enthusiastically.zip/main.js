document.addEventListener('DOMContentLoaded', () => {
  initApp();
});

function initApp() {
  updateAuthUI();
  renderTasks();
  initQuranData();
}

let currentUser = JSON.parse(localStorage.getItem('rafiqi_user')) || null;
const OWNER_EMAIL = 'mohamed373h1@gmail.com';

function updateAuthUI() {
  const nameEl = document.getElementById('user-name');
  const ownerBtn = document.getElementById('open-owner-btn');
  if (currentUser && nameEl) {
    nameEl.textContent = currentUser.name;
    if (ownerBtn) {
      if (currentUser.email === OWNER_EMAIL) ownerBtn.classList.remove('hidden');
      else ownerBtn.classList.add('hidden');
    }
  }
}

window.promptLogin = function() {
  const email = prompt('أدخل إيميل جوجل الخاص بك:', 'mohamed373h1@gmail.com');
  if (!email) return;
  const name = prompt('أدخل اسمك الكريم:', 'محمد يحيى');
  currentUser = { email: email.trim(), name: name ? name.trim() : 'مستخدم' };
  localStorage.setItem('rafiqi_user', JSON.stringify(currentUser));
  updateAuthUI();
  alert(`أهلاً بك يا ${currentUser.name}! تم تسجيل الدخول بنجاح.`);
};

const navItems = document.querySelectorAll('.nav-item');
const tabPanes = document.querySelectorAll('.tab-pane');

window.switchTab = function(targetId) {
  const toolScreen = document.getElementById('tool-screen');
  if (toolScreen) toolScreen.classList.add('hidden');
  
  tabPanes.forEach(pane => pane.classList.remove('active'));
  navItems.forEach(item => {
    if (item.dataset.target === targetId) item.classList.add('active');
    else item.classList.remove('active');
  });
  
  const activePane = document.getElementById(targetId);
  if (activePane) activePane.classList.add('active');
};

navItems.forEach(btn => {
  btn.addEventListener('click', () => switchTab(btn.dataset.target));
});

let currentMode = 'focus', isRunning = false, timerInterval = null, remainingSeconds = 25 * 60, completedSessions = 0;
const mainDisplay = document.getElementById('main-timer-display');
const floatDisplay = document.getElementById('float-timer-display');
const timerStatus = document.getElementById('timer-status');
const floatStatus = document.getElementById('float-status-text');
const startBtn = document.getElementById('start-timer-btn');
const floatPlayBtn = document.getElementById('float-play-btn');

function formatTime(sec) {
  const m = Math.floor(sec / 60).toString().padStart(2, '0');
  const s = (sec % 60).toString().padStart(2, '0');
  return `${m}:${s}`;
}

function updateTimerUI() {
  const formatted = formatTime(remainingSeconds);
  if (mainDisplay) mainDisplay.textContent = formatted;
  if (floatDisplay) floatDisplay.textContent = formatted;
  if (startBtn) startBtn.textContent = isRunning ? '⏸ إيقاف' : '▶ ابدأ';
  if (floatPlayBtn) floatPlayBtn.textContent = isRunning ? '⏸' : '▶';
  if (timerStatus) timerStatus.textContent = isRunning ? 'جارٍ التركيز...' : 'متوقف';
  if (floatStatus) floatStatus.textContent = isRunning ? 'جارٍ' : 'متوقف';
}

function toggleTimer() {
  if (isRunning) {
    clearInterval(timerInterval);
    isRunning = false;
  } else {
    isRunning = true;
    timerInterval = setInterval(() => {
      if (remainingSeconds > 0) {
        remainingSeconds--;
        updateTimerUI();
      } else {
        clearInterval(timerInterval);
        isRunning = false;
        if (currentMode === 'focus') {
          completedSessions++;
          const sessEl = document.getElementById('sessions-today');
          if (sessEl) sessEl.textContent = completedSessions;
        }
        alert('انتهت الجلسة!');
        resetTimer();
      }
    }, 1000);
  }
  updateTimerUI();
}

function resetTimer() {
  clearInterval(timerInterval);
  isRunning = false;
  remainingSeconds = currentMode === 'focus' ? 1500 : currentMode === 'short' ? 300 : 900;
  updateTimerUI();
  if (timerStatus) timerStatus.textContent = 'جاهز';
}

if (startBtn) startBtn.addEventListener('click', toggleTimer);
if (floatPlayBtn) floatPlayBtn.addEventListener('click', toggleTimer);
const resetBtn = document.getElementById('reset-timer-btn');
if (resetBtn) resetBtn.addEventListener('click', resetTimer);
const floatResetBtn = document.getElementById('float-reset-btn');
if (floatResetBtn) floatResetBtn.addEventListener('click', resetTimer);

document.querySelectorAll('.mode-btn[data-mode]').forEach(btn => {
  btn.addEventListener('click', () => {
    document.querySelectorAll('.mode-btn[data-mode]').forEach(b => b.classList.remove('active'));
    btn.classList.add('active');
    currentMode = btn.dataset.mode;
    resetTimer();
  });
});

const floatWidget = document.getElementById('floating-timer');
const dragHandle = document.getElementById('float-drag-handle');
const toggleFloatBtn = document.getElementById('toggle-float-btn');
const closeFloatBtn = document.getElementById('close-float-btn');
const floatExpandBtn = document.getElementById('float-expand-btn');

if (toggleFloatBtn && floatWidget) toggleFloatBtn.addEventListener('click', () => floatWidget.classList.toggle('hidden'));
if (closeFloatBtn && floatWidget) closeFloatBtn.addEventListener('click', () => floatWidget.classList.add('hidden'));
if (floatExpandBtn && floatWidget) floatExpandBtn.addEventListener('click', () => { floatWidget.classList.add('hidden'); switchTab('tab-study'); });

let offsetX = 0, offsetY = 0, isDragging = false;
if (dragHandle && floatWidget) {
  dragHandle.addEventListener('touchstart', (e) => {
    isDragging = true; const touch = e.touches[0]; const rect = floatWidget.getBoundingClientRect();
    offsetX = touch.clientX - rect.left; offsetY = touch.clientY - rect.top;
  });
  document.addEventListener('touchmove', (e) => {
    if (!isDragging) return; const touch = e.touches[0];
    floatWidget.style.left = `${touch.clientX - offsetX}px`;
    floatWidget.style.top = `${touch.clientY - offsetY}px`;
  });
  document.addEventListener('touchend', () => { isDragging = false; });
}

let tasks = JSON.parse(localStorage.getItem('rafiqi_tasks') || '[]');
function renderTasks() {
  const tasksList = document.getElementById('tasks-list');
  if (!tasksList) return;
  tasksList.innerHTML = '';
  let doneCount = 0;
  tasks.forEach((t, idx) => {
    if (t.done) doneCount++;
    const row = document.createElement('div');
    row.className = `task-row ${t.done ? 'done' : ''}`;
    row.innerHTML = `<span onclick="toggleTask(${idx})" style="cursor:pointer;flex:1;">${t.done ? '✅' : '⬜'} ${t.title}</span><button onclick="deleteTask(${idx})" class="text-link">حذف</button>`;
    tasksList.appendChild(row);
  });
  const ratioEl = document.getElementById('mini-tasks-ratio');
  if (ratioEl) ratioEl.textContent = `${doneCount}/${tasks.length}`;
  localStorage.setItem('rafiqi_tasks', JSON.stringify(tasks));
}

window.toggleTask = (idx) => { tasks[idx].done = !tasks[idx].done; renderTasks(); };
window.deleteTask = (idx) => { tasks.splice(idx, 1); renderTasks(); };
const addTaskBtn = document.getElementById('add-task-btn');
if (addTaskBtn) {
  addTaskBtn.addEventListener('click', () => {
    const taskInput = document.getElementById('new-task-input');
    if (!taskInput) return;
    const val = taskInput.value.trim();
    if (!val) return;
    tasks.push({ title: val, done: false });
    taskInput.value = '';
    renderTasks();
  });
}

const ownerModal = document.getElementById('owner-modal');
const openOwnerBtn = document.getElementById('open-owner-btn');
const closeOwnerBtn = document.getElementById('close-owner-btn');
if (openOwnerBtn && ownerModal) openOwnerBtn.addEventListener('click', () => ownerModal.classList.remove('hidden'));
if (closeOwnerBtn && ownerModal) closeOwnerBtn.addEventListener('click', () => ownerModal.classList.add('hidden'));

window.closeOwnerAndOpen = (toolKey) => {
  if (ownerModal) ownerModal.classList.add('hidden');
  openTool(toolKey);
};

const toolScreen = document.getElementById('tool-screen');
const toolTitle = document.getElementById('tool-screen-title');
const toolBody = document.getElementById('tool-screen-body');
const closeToolBtn = document.getElementById('close-tool-btn');
if (closeToolBtn && toolScreen) closeToolBtn.addEventListener('click', () => toolScreen.classList.add('hidden'));

window.openTool = function(toolKey) {
  if (!toolScreen || !toolTitle || !toolBody) return;
  toolScreen.classList.remove('hidden');

  if (toolKey === 'ai') {
    toolTitle.textContent = '🤖 المساعد الذكي';
    toolBody.innerHTML = `
      <div class="card"><h4>اسأل مساعدك الذكي</h4><p class="subtitle">اشرح أي درس أو استفسر عن مسألة.</p></div>
      <div id="ai-chat-box" class="card" style="min-height:180px;max-height:280px;overflow-y:auto;"><div style="color:var(--gold-light);">🤖 أهلاً بك! اكتب سؤالك هنا.</div></div>
      <div class="task-form"><input type="text" id="ai-prompt-input" placeholder="اكتب سؤالك..."><button onclick="sendAiMessage()" class="gold-btn">إرسال</button></div>
    `;
  } else if (toolKey === 'dict') {
    toolTitle.textContent = '文 قاموس ومترجم ناطق';
    toolBody.innerHTML = `
      <div class="card">
        <h4>ترجمة فورية مع نطق واضح ونسخ</h4>
        <textarea id="dict-input" class="full-textarea" rows="3" placeholder="اكتب النص هنا..."></textarea>
        <button onclick="translateText()" class="gold-btn" style="width:100%;margin-top:10px;">ترجم الآن</button>
      </div>
      <div class="card">
        <h4>النتيجة:</h4>
        <p id="dict-output" class="subtitle" style="font-size:16px;color:var(--gold-light);margin-top:8px;">ستظهر الترجمة هنا...</p>
        <div style="display:flex;gap:10px;margin-top:12px;">
          <button onclick="speakResult()" class="ctrl-btn secondary" style="flex:1;">🔊 نطق واضح</button>
          <button onclick="copyResult()" class="ctrl-btn secondary" style="flex:1;">📋 نسخ</button>
        </div>
      </div>
    `;
  } else if (toolKey === 'channel') {
    toolTitle.textContent = '📢 قناة النشر';
    const isOwner = currentUser && currentUser.email === OWNER_EMAIL;
    const posts = JSON.parse(localStorage.getItem('rafiqi_posts') || '[]');
    toolBody.innerHTML = `
      ${isOwner ? `
        <div class="card">
          <h4>🛡️ نشر إعلان أو ملف جديد (للمالك)</h4>
          <input type="text" id="post-title" class="full-input" placeholder="عنوان المنشور">
          <textarea id="post-body" class="full-textarea" rows="3" placeholder="التفاصيل..."></textarea>
          <button onclick="addPost()" class="gold-btn" style="margin-top:10px;width:100%;">نشر في القناة</button>
        </div>
      ` : `<div class="card"><p class="subtitle">قناة النشر الرسمية.</p></div>`}
      <div>${posts.length === 0 ? '<p class="subtitle" style="text-align:center;">لا توجد منشورات.</p>' : posts.map(p => `<div class="card"><h4 style="color:var(--gold-light);">${p.title}</h4><p style="margin-top:6px;">${p.body}</p></div>`).join('')}</div>
    `;
  } else if (toolKey === 'pdf') {
    toolTitle.textContent = '📄 قارئ PDF المطور';
    toolBody.innerHTML = `
      <div class="card" style="display:flex;justify-content:space-between;align-items:center;">
        <div><h4 id="pdf-file-name" style="font-size:14px;color:var(--gold-light);">اختر ملف PDF</h4></div>
        <label class="gold-btn" style="cursor:pointer;padding:6px 14px;">📂 اختر ملف<input type="file" accept="application/pdf" style="display:none;" onchange="loadPdfFile(event)"></label>
      </div>
      <div id="pdf-workspace" class="hidden">
        <div class="pdf-nav-bar">
          <div style="display:flex;gap:6px;align-items:center;">
            <button class="pdf-icon-btn" onclick="changePdfPage(-1)">◀</button>
            <span style="font-size:13px;">صفحة <input type="number" id="pdf-page-num" value="1" style="width:40px;text-align:center;background:transparent;color:var(--gold-light);border:none;border-bottom:1px solid var(--gold);" onchange="jumpPdfPage(this.value)"> من <b id="pdf-total">1</b></span>
            <button class="pdf-icon-btn" onclick="changePdfPage(1)">▶</button>
          </div>
        </div>
        <div class="pdf-stage-Scroll" id="pdf-scroll" style="width:100%;height:50vh;background:#12100c;overflow:auto;display:flex;justify-content:center;align-items:flex-start;padding:10px;">
          <div class="pdf-canvas-stack" id="pdf-stack" style="position:relative;background:#fff;"><canvas id="pdf-canvas"></canvas></div>
        </div>
      </div>
    `;
  } else if (toolKey === 'books') {
    toolTitle.textContent = '📚 الكتب والامتحانات';
    const isOwner = currentUser && currentUser.email === OWNER_EMAIL;
    const books = JSON.parse(localStorage.getItem('rafiqi_books') || '[]');
    toolBody.innerHTML = `
      ${isOwner ? `
        <div class="card">
          <h4>🛡️ رفع كتاب أو امتحان (للمالك)</h4>
          <input type="text" id="book-name" class="full-input" placeholder="اسم الكتاب">
          <input type="text" id="book-link" class="full-input" placeholder="رابط التحميل المباشر">
          <button onclick="addBook()" class="gold-btn" style="margin-top:10px;width:100%;">+ رفع الملف</button>
        </div>
      ` : ''}
      <div class="tools-list">${books.length === 0 ? '<p class="subtitle" style="text-align:center;">لا توجد كتب مرفوعة.</p>' : books.map(b => `<div class="tool-item"><div class="tool-icon">📘</div><div class="tool-info"><h4>${b.name}</h4></div><a href="${b.link}" target="_blank" class="gold-btn" style="padding:6px 12px;font-size:12px;text-decoration:none;">تنزيل ⬇</a></div>`).join('')}</div>
    `;
  } else if (toolKey === 'youtube') {
    toolTitle.textContent = '▶️ يوتيوب للدراسة';
    toolBody.innerHTML = `
      <div class="card">
        <h4>شاهد درسك بدون إعلانات</h4>
        <input type="text" id="yt-url" class="full-input" placeholder="الصق رابط يوتيوب هنا...">
        <button onclick="playYoutube()" class="gold-btn" style="width:100%;margin-top:10px;">▶ تشغيل الفيديو</button>
      </div>
      <div id="yt-box" class="card hidden"><iframe id="yt-frame" style="width:100%;height:220px;border:none;border-radius:12px;" allowfullscreen></iframe></div>
    `;
  } else if (toolKey === 'whiteboard') {
    toolTitle.textContent = '✏️ السبورة البيضاء';
    toolBody.innerHTML = `<div class="card"><button onclick="clearBoard()" class="float-trigger-btn" style="margin-bottom:10px;">🗑️ مسح السبورة</button><canvas id="wb-canvas" style="width:100%;height:320px;background:#14120e;border-radius:12px;"></canvas></div>`;
    setTimeout(initWb, 50);
  } else if (toolKey === 'schedule') {
    toolTitle.textContent = '📅 الجدول الأسبوعي';
    const days = ['السبت', 'الأحد', 'الاثنين', 'الثلاثاء', 'الأربعاء', 'الخميس', 'الجمعة'];
    const sched = JSON.parse(localStorage.getItem('rafiqi_sched') || '{}');
    toolBody.innerHTML = days.map(d => `<div class="card" style="padding:12px;"><label style="color:var(--gold-light);font-weight:700;">📌 ${d}</label><input type="text" class="full-input" value="${sched[d] || ''}" placeholder="أضف دروس اليوم..." onchange="saveSched('${d}', this.value)"></div>`).join('');
  } else if (toolKey === 'calc') {
    toolTitle.textContent = '🧮 آلة حاسبة';
    toolBody.innerHTML = `
      <div class="card">
        <input type="text" id="calc-scr" class="full-input" style="font-size:24px;text-align:left;direction:ltr;color:var(--gold-light);" readonly>
        <div style="display:grid;grid-template-columns:repeat(4,1fr);gap:8px;margin-top:10px;">
          <button class="ctrl-btn secondary" onclick="calcAction('C')">C</button>
          <button class="ctrl-btn secondary" onclick="calcAction('(')">(</button>
          <button class="ctrl-btn secondary" onclick="calcAction(')')">)</button>
          <button class="ctrl-btn secondary" onclick="calcAction('/')">÷</button>
          <button class="ctrl-btn secondary" onclick="calcAction('7')">7</button>
          <button class="ctrl-btn secondary" onclick="calcAction('8')">8</button>
          <button class="ctrl-btn secondary" onclick="calcAction('9')">9</button>
          <button class="ctrl-btn secondary" onclick="calcAction('*')">×</button>
          <button class="ctrl-btn secondary" onclick="calcAction('4')">4</button>
          <button class="ctrl-btn secondary" onclick="calcAction('5')">5</button>
          <button class="ctrl-btn secondary" onclick="calcAction('6')">6</button>
          <button class="ctrl-btn secondary" onclick="calcAction('-')">−</button>
          <button class="ctrl-btn secondary" onclick="calcAction('1')">1</button>
          <button class="ctrl-btn secondary" onclick="calcAction('2')">2</button>
          <button class="ctrl-btn secondary" onclick="calcAction('3')">3</button>
          <button class="ctrl-btn secondary" onclick="calcAction('+')">+</button>
          <button class="ctrl-btn secondary" onclick="calcAction('0')">0</button>
          <button class="ctrl-btn secondary" onclick="calcAction('.')">.</button>
          <button class="ctrl-btn secondary" onclick="calcAction('DEL')">⌫</button>
          <button class="ctrl-btn primary" onclick="calcResult()">=</button>
        </div>
      </div>
    `;
  } else if (toolKey === 'khatmah') {
    toolTitle.textContent = '📖 ختمة القرآن';
    let p = parseInt(localStorage.getItem('khatmah_p') || '0');
    let pct = Math.min(100, Math.round((p / 604) * 100));
    toolBody.innerHTML = `
      <div class="card">
        <div class="row-between"><h3>متابعة الختمة</h3><button onclick="localStorage.setItem('khatmah_p', 0); openTool('khatmah');" class="float-trigger-btn">إعادة</button></div>
        <p style="margin:10px 0;color:var(--gold-light);">الصفحة الحالية: <b>${p}</b> من 604 (${pct}%)</p>
        <div style="display:grid;grid-template-columns:1fr 1fr;gap:8px;margin-top:10px;">
          <button onclick="addKhatmah(1)" class="ctrl-btn secondary">+ صفحة</button>
          <button onclick="addKhatmah(10)" class="gold-btn">+ 10 صفحات</button>
        </div>
      </div>
    `;
  } else if (toolKey === 'prayer') {
    toolTitle.textContent = '🕌 مواقيت الصلاة';
    const govs = ['Qena', 'Cairo', 'Alexandria', 'Aswan', 'Luxor', 'Sohag', 'Asyut', 'Minya'];
    toolBody.innerHTML = `
      <div class="card"><label style="font-size:12px;color:var(--text-muted);">المحافظة:</label><select class="full-select" onchange="fetchPrayerTimesData(this.value)">${govs.map(g => `<option value="${g}">${g}</option>`).join('')}</select></div>
      <div id="prayer-box" class="card"><p style="text-align:center;color:var(--gold-light);">جارٍ التحميل...</p></div>
    `;
    fetchPrayerTimesData('Qena');
  }
};

window.sendAiMessage = () => {
  const inp = document.getElementById('ai-prompt-input');
  const box = document.getElementById('ai-chat-box');
  if (!inp || !box) return;
  const val = inp.value.trim();
  if(!val) return;
  box.innerHTML += `<div style="margin:6px 0;"><b>أنت:</b> ${val}</div><div style="margin:6px 0;color:var(--gold-light);"><b>المساعد:</b> سؤال ممتاز! راجع كتاب المنهج حول (${val}).</div>`;
  inp.value = ''; box.scrollTop = box.scrollHeight;
};

window.translateText = async () => {
  const txtInput = document.getElementById('dict-input');
  const out = document.getElementById('dict-output');
  if (!txtInput || !out) return;
  const txt = txtInput.value.trim();
  if(!txt) return;
  out.textContent = 'جارٍ الترجمة...';
  try {
    const res = await fetch(`https://api.mymemory.translated.net/get?q=${encodeURIComponent(txt)}&langpair=en|ar`);
    const data = await res.json();
    out.textContent = data.responseData.translatedText || 'تعذر الترجمة.';
  } catch(e) { out.textContent = 'خطأ في الاتصال بالإنترنت.'; }
};

window.speakResult = () => {
  const text = document.getElementById('dict-output')?.textContent;
  if(text && 'speechSynthesis' in window) {
    const utter = new SpeechSynthesisUtterance(text);
    utter.lang = 'ar-SA'; window.speechSynthesis.speak(utter);
  }
};

window.copyResult = () => {
  const text = document.getElementById('dict-output')?.textContent;
  if (text) {
    navigator.clipboard.writeText(text);
    alert('تم النسخ بنجاح!');
  }
};

window.addPost = () => {
  const title = document.getElementById('post-title')?.value.trim();
  const body = document.getElementById('post-body')?.value.trim();
  if(!title || !body) return;
  const posts = JSON.parse(localStorage.getItem('rafiqi_posts') || '[]');
  posts.unshift({ title, body });
  localStorage.setItem('rafiqi_posts', JSON.stringify(posts));
  openTool('channel');
};

window.addBook = () => {
  const name = document.getElementById('book-name')?.value.trim();
  const link = document.getElementById('book-link')?.value.trim();
  if(!name || !link) return;
  const books = JSON.parse(localStorage.getItem('rafiqi_books') || '[]');
  books.unshift({ name, link });
  localStorage.setItem('rafiqi_books', JSON.stringify(books));
  openTool('books');
};

window.playYoutube = () => {
  const url = document.getElementById('yt-url')?.value.trim();
  if (!url) return;
  let id = '';
  if(url.includes('v=')) id = url.split('v=')[1].split('&')[0];
  else if(url.includes('youtu.be/')) id = url.split('youtu.be/')[1].split('?')[0];
  if(!id) return alert('رابط غير صحيح');
  const ytBox = document.getElementById('yt-box');
  const ytFrame = document.getElementById('yt-frame');
  if (ytBox && ytFrame) {
    ytBox.classList.remove('hidden');
    ytFrame.src = `https://www.youtube.com/embed/${id}`;
  }
};

function to12Hours(timeStr) {
  if(!timeStr) return '';
  const [h, m] = timeStr.split(':');
  let hour = parseInt(h);
  const ampm = hour >= 12 ? 'م' : 'ص';
  hour = hour % 12; hour = hour ? hour : 12;
  return `${hour}:${m} ${ampm}`;
}

async function fetchPrayerTimesData(city) {
  const box = document.getElementById('prayer-box');
  try {
    const res = await fetch(`https://api.aladhan.com/v1/timingsByCity?city=${city}&country=Egypt&method=5`);
    const data = await res.json();
    const t = data.data.timings;
    const govName = document.getElementById('mini-gov-name');
    const miniTime = document.getElementById('mini-prayer-time');
    if (govName) govName.textContent = city;
    if (miniTime) miniTime.textContent = to12Hours(t.Fajr);
    if (box) {
      box.innerHTML = `
        <div class="task-row"><span>الفجر</span><strong style="color:var(--gold-light);">${to12Hours(t.Fajr)}</strong></div>
        <div class="task-row"><span>الشروق</span><strong>${to12Hours(t.Sunrise)}</strong></div>
        <div class="task-row"><span>الظهر</span><strong style="color:var(--gold-light);">${to12Hours(t.Dhuhr)}</strong></div>
        <div class="task-row"><span>العصر</span><strong style="color:var(--gold-light);">${to12Hours(t.Asr)}</strong></div>
        <div class="task-row"><span>المغرب</span><strong style="color:var(--gold-light);">${to12Hours(t.Maghrib)}</strong></div>
        <div class="task-row"><span>العشاء</span><strong style="color:var(--gold-light);">${to12Hours(t.Isha)}</strong></div>
      `;
    }
  } catch(e) { if(box) box.innerHTML = '<p class="subtitle">تعذر جلب الأوقات.</p>'; }
}

let allSurahs = [], activeSurahNum = 1;
const sheikhsList = [
  { name: 'ياسر الدوسري', id: 'yasser' },
  { name: 'مشاري العفاسي', id: 'afasy' },
  { name: 'عبدالرحمن السديس', id: 'sudais' },
  { name: 'محمود الحصري', id: 'husary' },
  { name: 'محمد المنشاوي', id: 'minshawi' }
];
let currentSheikh = 'yasser';

async function initQuranData() {
  const container = document.getElementById('surahs-container');
  if (!container) return;
  try {
    const res = await fetch('https://api.alquran.cloud/v1/surah');
    const data = await res.json();
    allSurahs = data.data;
    container.innerHTML = allSurahs.map(s => `
      <div class="tool-item" onclick="openSurah(${s.number}, '${s.name}')">
        <div class="tool-icon" style="color:var(--gold-light);">${s.number}</div>
        <div class="tool-info"><h4>${s.name}</h4><p>${s.revelationType === 'Meccan' ? 'مكية' : 'مدنية'} · ${s.numberOfAyahs} آية</p></div>
        <span class="arrow">‹</span>
      </div>
    `).join('');
  } catch(e) { container.innerHTML = '<p class="subtitle">خطأ في تحميل السور.</p>'; }
}

window.openSurah = async (num, name) => {
  activeSurahNum = num;
  const listView = document.getElementById('quran-list-view');
  const readerView = document.getElementById('quran-reader-view');
  if (listView) listView.classList.add('hidden');
  if (readerView) readerView.classList.remove('hidden');
  const titleEl = document.getElementById('current-surah-title');
  if (titleEl) titleEl.textContent = name;
  const bismillahBar = document.getElementById('bismillah-bar');
  if (bismillahBar) bismillahBar.style.display = (num === 1 || num === 9) ? 'none' : 'block';

  renderSheikhsUI();
  loadQuranAudio(num, currentSheikh);

  const ayahsBox = document.getElementById('ayahs-container');
  if (ayahsBox) {
    ayahsBox.innerHTML = 'جارٍ التحميل...';
    try {
      const res = await fetch(`https://api.alquran.cloud/v1/surah/${num}/quran-uthmani`);
      const data = await res.json();
      ayahsBox.innerHTML = data.data.ayahs.map(a => `
        <span class="ayah-item" onclick="openTafseerModal(${num}, ${a.numberInSurah}, '${a.text.replace(/'/g, "\\'")}')">
          ${a.text} <span class="ayah-num">﴿${a.numberInSurah}﴾</span>
        </span>
      `).join(' ');
    } catch(e) { ayahsBox.innerHTML = 'تعذر تحميل الآيات.'; }
  }
};

window.closeSurahReader = () => {
  const listView = document.getElementById('quran-list-view');
  const readerView = document.getElementById('quran-reader-view');
  if (listView) listView.classList.remove('hidden');
  if (readerView) readerView.classList.add('hidden');
};

function renderSheikhsUI() {
  const grid = document.getElementById('sheikhs-grid');
  if (!grid) return;
  grid.innerHTML = sheikhsList.map(sh => `
    <button class="sheikh-btn ${sh.id === currentSheikh ? 'active' : ''}" onclick="setSheikhChoice('${sh.id}')">${sh.name}</button>
  `).join('');
}

window.setSheikhChoice = (id) => {
  currentSheikh = id;
  renderSheikhsUI();
  loadQuranAudio(activeSurahNum, id);
};

function loadQuranAudio(num, shId) {
  const player = document.getElementById('quran-audio-player');
  if (!player) return;
  const pad = num.toString().padStart(3, '0');
  const urls = {
    'yasser': `https://server11.mp3quran.net/yasser/${pad}.mp3`,
    'afasy': `https://server8.mp3quran.net/afs/${pad}.mp3`,
    'sudais': `https://server11.mp3quran.net/sds/${pad}.mp3`,
    'husary': `https://server13.mp3quran.net/husr/${pad}.mp3`,
    'minshawi': `https://server10.mp3quran.net/minsh/${pad}.mp3`
  };
  player.src = urls[shId] || urls['yasser'];
  player.play().catch(() => {});
}

const toggleSheikhsBtn = document.getElementById('toggle-sheikhs-btn');
if (toggleSheikhsBtn) {
  toggleSheikhsBtn.addEventListener('click', () => {
    document.getElementById('sheikhs-box')?.classList.toggle('hidden');
  });
}

window.openTafseerModal = async (sNum, aNum, text) => {
  const modal = document.getElementById('tafseer-modal');
  if (modal) modal.classList.remove('hidden');
  const title = document.getElementById('tafseer-title');
  if (title) title.textContent = `تفسير الآية ${aNum}`;
  const ayahBox = document.getElementById('tafseer-ayah-box');
  if (ayahBox) ayahBox.textContent = text;
  const box = document.getElementById('tafseer-content-box');
  if (box) {
    box.textContent = 'جارٍ جلب التفسير...';
    try {
      const res = await fetch(`https://api.alquran.cloud/v1/ayah/${sNum}:${aNum}/ar.muyassar`);
      const data = await res.json();
      box.textContent = data.data.text;
    } catch(e) { box.textContent = 'التفسير غير متوفر حالياً.'; }
  }
};

window.closeTafseerModal = () => document.getElementById('tafseer-modal')?.classList.add('hidden');

const azkarData = {
  morning: [
    { text: 'أَصْبَحْنَا وَأَصْبَحَ الْمُلْكُ لِلَّهِ، وَالْحَمْدُ لِلَّهِ، لاَ إِلَهَ إلاَّ اللَّهُ وَحْدَهُ لاَ شَرِيكَ لَهُ.', count: 1 },
    { text: 'اللَّهُمَّ بِكَ أَصْبَحْنَا، وَبِكَ أَمْسَيْنَا، وَبِكَ نَحْيَا، وَبِكَ نَمُوتُ وَإِلَيْكَ النُّشُورُ.', count: 1 },
    { text: 'سُبْحَانَ اللَّهِ وَبِحَمْدِهِ.', count: 100 }
  ],
  evening: [
    { text: 'أَمْسَيْنَا وَأَمْسَى الْمُلْكُ لِلَّهِ، وَالْحَمْدُ لِلَّهِ، لاَ إِلَهَ إلاَّ اللَّهُ وَحْدَهُ لاَ شَرِيكَ لَهُ.', count: 1 },
    { text: 'أَعُوذُ بِكَلِمَاتِ اللَّهِ التَّامَّاتِ مِنْ شَرِّ مَا خَلَقَ.', count: 3 }
  ],
  sleep: [
    { text: 'بِاسْمِكَ رَبِّ وَضَعْتُ جَنْبِي، وَبِكَ أَرْفَعُهُ، إِنْ أَمْسَكْتَ نَفْسِي فَارْحَمْهَا.', count: 1 },
    { text: 'اللَّهُمَّ قِنِي عَذَابَكَ يَوْمَ تَبْعَثُ عِبَادَكَ.', count: 3 }
  ],
  study: [
    { text: 'رَبِّ زِدْنِي عِلْمًا.', count: 3 },
    { text: 'اللَّهُمَّ لَا سَهْلَ إِلَّا ما جَعَلْتَهُ سَهْلاً، وأنتَ تجَعَلُ الحَزْنَ إذا شِئْتَ سَهْلاً.', count: 1 }
  ]
};

window.renderAzkar = (type, btn) => {
  if (btn) {
    btn.parentElement.querySelectorAll('.mode-btn').forEach(b => b.classList.remove('active'));
    btn.classList.add('active');
  }
  const box = document.getElementById('azkar-container');
  if (!box) return;
  if (type === 'tasbeeh') {
    box.innerHTML = `
      <div class="card" style="text-align:center;">
        <h3>📿 السبحة الإلكترونية الصحيحة</h3>
        <p class="subtitle" id="tasbeeh-label">سبحان الله (33 مرة)</p>
        <div id="tasbeeh-num" class="timer-digits" style="margin:16px 0;">0</div>
        <button onclick="incTasbeeh()" class="ctrl-btn primary" style="width:130px;height:130px;border-radius:50%;font-size:22px;">سبّح</button>
        <div style="margin-top:14px;"><button onclick="resetTasbeeh()" class="text-link">إعادة من البداية</button></div>
      </div>
    `;
  } else {
    box.innerHTML = azkarData[type].map(z => `
      <div class="card" onclick="let c=this.querySelector('strong'); if(parseInt(c.textContent)>0) c.textContent=parseInt(c.textContent)-1;" style="cursor:pointer;">
        <p style="font-size:16px;line-height:1.7;">${z.text}</p>
        <div class="row-between" style="margin-top:8px;"><span class="subtitle">اضغط للعد</span><strong style="color:var(--gold-light);font-size:18px;">${z.count}</strong></div>
      </div>
    `).join('');
  }
};

let tasbeehCount = 0, tasbeehRound = 0;
const tasbeehPhrases = ['سبحان الله (33 مرة)', 'الحمد لله (33 مرة)', 'الله أكبر (33 مرة)', 'لا إله إلا الله وحده لا شريك له (مرة واحدة)'];
const tasbeehLimits = [33, 33, 33, 1];

window.incTasbeeh = () => {
  tasbeehCount++;
  const limit = tasbeehLimits[tasbeehRound];
  const numEl = document.getElementById('tasbeeh-num');
  if (numEl) numEl.textContent = tasbeehCount;
  if(tasbeehCount >= limit) {
    tasbeehRound = (tasbeehRound + 1) % tasbeehPhrases.length;
    tasbeehCount = 0;
    const labelEl = document.getElementById('tasbeeh-label');
    if (labelEl) labelEl.textContent = tasbeehPhrases[tasbeehRound];
    alert('انتقلت للذكر التالي!');
  }
};

window.resetTasbeeh = () => {
  tasbeehCount = 0; tasbeehRound = 0;
  const numEl = document.getElementById('tasbeeh-num');
  const labelEl = document.getElementById('tasbeeh-label');
  if (numEl) numEl.textContent = '0';
  if (labelEl) labelEl.textContent = tasbeehPhrases[0];
};

let pdfDoc = null, pdfPage = 1, pdfScale = 1.0;
window.loadPdfFile = (e) => {
  const file = e.target.files[0]; if(!file) return;
  const nameEl = document.getElementById('pdf-file-name');
  const workspace = document.getElementById('pdf-workspace');
  if (nameEl) nameEl.textContent = '📄 ' + file.name;
  if (workspace) workspace.classList.remove('hidden');
  const reader = new FileReader();
  reader.onload = async function() {
    try {
      if (window.pdfjsLib) {
        pdfDoc = await pdfjsLib.getDocument(new Uint8Array(this.result)).promise;
        const totalEl = document.getElementById('pdf-total');
        if (totalEl) totalEl.textContent = pdfDoc.numPages;
        renderPdfPageSafe(1);
      }
    } catch(err) { alert('خطأ في تحميل ملف PDF.'); }
  };
  reader.readAsArrayBuffer(file);
};

async function renderPdfPageSafe(num) {
  if(!pdfDoc) return;
  const page = await pdfDoc.getPage(num);
  const viewport = page.getViewport({ scale: pdfScale });
  const canvas = document.getElementById('pdf-canvas');
  if (!canvas) return;
  canvas.width = viewport.width; canvas.height = viewport.height;
  const pageNumInp = document.getElementById('pdf-page-num');
  const zoomLbl = document.getElementById('pdf-zoom');
  if (pageNumInp) pageNumInp.value = num;
  if (zoomLbl) zoomLbl.textContent = Math.round(pdfScale * 100) + '%';
  await page.render({ canvasContext: canvas.getContext('2d'), viewport }).promise;
}

window.changePdfPage = (d) => { if(!pdfDoc) return; const p = pdfPage + d; if(p >= 1 && p <= pdfDoc.numPages) { pdfPage = p; renderPdfPageSafe(p); } };
window.jumpPdfPage = (v) => { let p = parseInt(v); if(pdfDoc && p >= 1 && p <= pdfDoc.numPages) { pdfPage = p; renderPdfPageSafe(p); } };
window.changePdfZoom = (d) => { pdfScale = Math.min(2.0, Math.max(0.6, +(pdfScale + d).toFixed(1))); renderPdfPageSafe(pdfPage); };

function initWb() {
  const canvas = document.getElementById('wb-canvas');
  if(!canvas) return;
  canvas.width = canvas.offsetWidth; canvas.height = canvas.offsetHeight;
  const ctx = canvas.getContext('2d'); ctx.strokeStyle = '#f3c65f'; ctx.lineWidth = 3; ctx.lineCap = 'round';
  let drawing = false;
  const getPos = (e) => {
    const r = canvas.getBoundingClientRect();
    return { x: (e.touches ? e.touches[0].clientX : e.clientX) - r.left, y: (e.touches ? e.touches[0].clientY : e.clientY) - r.top };
  };
  canvas.onmousedown = (e) => { drawing = true; const p = getPos(e); ctx.beginPath(); ctx.moveTo(p.x, p.y); };
  canvas.onmousemove = (e) => { if(!drawing) return; const p = getPos(e); ctx.lineTo(p.x, p.y); ctx.stroke(); };
  canvas.onmouseup = () => { drawing = false; };
  canvas.ontouchstart = canvas.onmousedown; canvas.ontouchmove = canvas.onmousemove; canvas.ontouchend = canvas.onmouseup;
}
window.clearBoard = () => {
  const canvas = document.getElementById('wb-canvas');
  if (canvas) canvas.getContext('2d').clearRect(0, 0, canvas.width, canvas.height);
};

window.saveSched = (day, val) => {
  const sched = JSON.parse(localStorage.getItem('rafiqi_sched') || '{}');
  sched[day] = val; localStorage.setItem('rafiqi_sched', JSON.stringify(sched));
};

window.calcAction = (v) => {
  const scr = document.getElementById('calc-scr');
  if (!scr) return;
  if(v === 'C') scr.value = '';
  else if(v === 'DEL') scr.value = scr.value.slice(0, -1);
  else scr.value += v;
};

window.calcResult = () => {
  const scr = document.getElementById('calc-scr');
  if (!scr) return;
  try { scr.value = Function('"use strict";return (' + scr.value + ')')(); } catch { scr.value = 'خطأ'; }
};

window.addKhatmah = (n) => {
  let p = parseInt(localStorage.getItem('khatmah_p') || '0') + n;
  if (p > 604) p = 604;
  localStorage.setItem('khatmah_p', p);
  openTool('khatmah');
};
